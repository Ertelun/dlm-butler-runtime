# DLD-054 C0R2 OwnedKeys diagnostic runtime candidate

This is a NEW, source-first diagnostic runtime candidate.

It is **not** a reconstruction of the provenance-incomplete historical C0R source.

Upstream baseline reference:
`Ertelun/dlm-butler-runtime@df08694965774a31041d6bd55915215568055908`

The C0R2 module is self-contained and additive. Its JSON-RPC routing surface is exactly:

- `Version.Get`
- `Meta.Shutdown`
- `Fetch.ProfileOwnedKeys`

The production provider base URL is explicit in source. Offline tests inject a synthetic HTTP doer/base URL and use only synthetic credentials/data.

No live provider use is authorized by this source package.
