package main

import (
	"context"
	"fmt"
	"os"

	c0r2runtime "dld.local/c0r2runtime"
	"dld.local/c0r2runtime/internal/buildinfo"
)

func main() {
	if len(os.Args) == 2 && (os.Args[1] == "-V" || os.Args[1] == "--version") {
		fmt.Println(buildinfo.VersionString())
		return
	}
	if !validDaemonArgs(os.Args[1:]) {
		fmt.Fprintln(os.Stderr, "C0R2 diagnostic runtime only supports: daemon --json --transport stdio")
		os.Exit(2)
	}
	store, err := c0r2runtime.OpenPlatformStore(os.Getenv("DLD_PROVIDER_STATE_DIR"))
	if err != nil {
		fmt.Fprintln(os.Stderr, "provider state initialization failed")
		os.Exit(1)
	}
	runtime, err := c0r2runtime.New(c0r2runtime.Config{
		Store:      store,
		APIBaseURL: c0r2runtime.ProductionProviderBaseURL,
	})
	if err != nil {
		fmt.Fprintln(os.Stderr, "runtime initialization failed")
		os.Exit(1)
	}
	if err := c0r2runtime.ServeStdio(context.Background(), os.Stdin, os.Stdout, runtime); err != nil {
		fmt.Fprintln(os.Stderr, "stdio runtime terminated with an error")
		os.Exit(1)
	}
}

func validDaemonArgs(args []string) bool {
	if len(args) != 4 || args[0] != "daemon" {
		return false
	}
	seenJSON := false
	seenTransport := false
	for i := 1; i < len(args); i++ {
		switch args[i] {
		case "--json":
			seenJSON = true
		case "--transport":
			if i+1 >= len(args) || args[i+1] != "stdio" {
				return false
			}
			seenTransport = true
			i++
		default:
			return false
		}
	}
	return seenJSON && seenTransport
}
