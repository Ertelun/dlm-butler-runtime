package c0r2runtime

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
	"unicode/utf8"

	"dld.local/c0r2runtime/internal/buildinfo"
)

const (
	ProductionProviderBaseURL = "https://api.itch.io"
	OwnedKeysProviderPath     = "/profile/owned-keys"
	OwnedKeysFixedPage        = "1"
	OwnedKeysUserAgent        = "DLD-C0R2-OwnedKeys-Diagnostic/1"
	maximumTitleRunes         = 512
)

type HTTPDoer interface {
	Do(*http.Request) (*http.Response, error)
}

type Config struct {
	Store      ProfileStore
	APIBaseURL string
	HTTPClient HTTPDoer
}

type Runtime struct {
	store      ProfileStore
	apiBaseURL string
	httpClient HTTPDoer
}

func New(cfg Config) (*Runtime, error) {
	if cfg.Store == nil {
		return nil, errors.New("store is required")
	}
	if cfg.APIBaseURL == "" {
		cfg.APIBaseURL = ProductionProviderBaseURL
	}
	base, err := url.Parse(cfg.APIBaseURL)
	if err != nil || base.Scheme == "" || base.Host == "" || base.User != nil || base.RawQuery != "" || base.Fragment != "" {
		return nil, errors.New("provider base URL is invalid")
	}
	if cfg.HTTPClient == nil {
		cfg.HTTPClient = newProductionHTTPClient()
	}
	return &Runtime{
		store:      cfg.Store,
		apiBaseURL: strings.TrimRight(cfg.APIBaseURL, "/"),
		httpClient: cfg.HTTPClient,
	}, nil
}

func newProductionHTTPClient() *http.Client {
	transport := http.DefaultTransport.(*http.Transport).Clone()
	transport.DisableKeepAlives = true
	transport.ForceAttemptHTTP2 = false
	transport.MaxConnsPerHost = 1
	return &http.Client{
		Transport: transport,
		Timeout:   20 * time.Second,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}

func (r *Runtime) Handle(ctx context.Context, method string, raw json.RawMessage) (any, bool, error) {
	switch method {
	case "Version.Get":
		return map[string]any{
			"version":       buildinfo.Version,
			"versionString": buildinfo.VersionString(),
		}, false, nil
	case "Meta.Shutdown":
		return map[string]any{}, true, nil
	case "Fetch.ProfileOwnedKeys":
		res, err := r.fetchProfileOwnedKeys(ctx, raw)
		return res, false, err
	default:
		return nil, false, methodNotFound()
	}
}

type providerOwnedKeysEnvelope struct {
	Page      *int64            `json:"page"`
	PerPage   *int64            `json:"perPage"`
	OwnedKeys []json.RawMessage `json:"ownedKeys"`
}

type providerOwnedKey struct {
	ID     *int64        `json:"id"`
	GameID *int64        `json:"gameId"`
	Game   *providerGame `json:"game"`
}

type providerGame struct {
	ID        *int64  `json:"id"`
	Title     *string `json:"title"`
	MinPrice  *int64  `json:"minPrice"`
	Published *bool   `json:"published"`
}

func (r *Runtime) fetchProfileOwnedKeys(ctx context.Context, raw json.RawMessage) (*FetchProfileOwnedKeysResult, error) {
	var p FetchProfileOwnedKeysParams
	if err := decodeStrictParams(raw, &p); err != nil {
		return nil, err
	}
	if p.ProfileID <= 0 {
		return nil, invalidParams("profileId must be greater than zero")
	}
	if p.Limit < 1 || p.Limit > 100 {
		return nil, invalidParams("limit must be in range 1..100")
	}
	if !p.Fresh {
		return nil, invalidParams("fresh=true is required")
	}

	profile, err := r.store.LoadProfile(p.ProfileID)
	if err != nil || profile.ID != p.ProfileID || profile.APIKey == "" {
		return nil, operationFailed("profile is not available")
	}

	reqURL := r.apiBaseURL + OwnedKeysProviderPath + "?page=" + OwnedKeysFixedPage
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, reqURL, nil)
	if err != nil {
		return nil, operationFailed("provider request construction failed")
	}
	req.Header.Set("Authorization", profile.APIKey)
	req.Header.Set("Accept", "application/vnd.itch.v2")
	req.Header.Set("User-Agent", OwnedKeysUserAgent)

	resp, err := r.httpClient.Do(req)
	if err != nil {
		// Never surface the underlying URL/transport error because it may include
		// provider or credential material.
		return nil, operationFailed("provider request failed")
	}
	if resp == nil {
		return nil, operationFailed("provider response is missing")
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, operationFailed(fmt.Sprintf("provider request failed with HTTP status %d", resp.StatusCode))
	}

	body, err := io.ReadAll(io.LimitReader(resp.Body, 4*1024*1024+1))
	if err != nil {
		return nil, operationFailed("provider response read failed")
	}
	if len(body) > 4*1024*1024 {
		return nil, operationFailed("provider response exceeds diagnostic limit")
	}

	envelope, err := decodeProviderOwnedKeysEnvelope(body)
	if err != nil {
		return nil, operationFailed("provider response decode failed")
	}

	max := int(p.Limit)
	if len(envelope.OwnedKeys) < max {
		max = len(envelope.OwnedKeys)
	}
	items := make([]*OwnedKey, 0, max)
	for i := 0; i < max; i++ {
		item, err := parseProviderOwnedKey(envelope.OwnedKeys[i])
		if err != nil {
			return nil, operationFailed("provider owned-key item failed validation")
		}
		items = append(items, item)
	}
	return &FetchProfileOwnedKeysResult{Items: items}, nil
}

func decodeProviderOwnedKeysEnvelope(body []byte) (*providerOwnedKeysEnvelope, error) {
	trimmed := bytes.TrimSpace(body)
	if len(trimmed) == 0 || trimmed[0] != '{' {
		return nil, errors.New("provider response is not an object")
	}

	var raw map[string]json.RawMessage
	if err := json.Unmarshal(trimmed, &raw); err != nil {
		return nil, err
	}
	ownedRaw, ok := raw["ownedKeys"]
	if !ok || bytes.Equal(bytes.TrimSpace(ownedRaw), []byte("null")) {
		return nil, errors.New("ownedKeys is missing or null")
	}
	var owned []json.RawMessage
	if err := json.Unmarshal(ownedRaw, &owned); err != nil {
		return nil, errors.New("ownedKeys is not an array")
	}

	env := &providerOwnedKeysEnvelope{OwnedKeys: owned}
	if pageRaw, ok := raw["page"]; ok && !bytes.Equal(bytes.TrimSpace(pageRaw), []byte("null")) {
		var page int64
		if err := json.Unmarshal(pageRaw, &page); err != nil {
			return nil, errors.New("page is invalid")
		}
		env.Page = &page
	}
	if perPageRaw, ok := raw["perPage"]; ok && !bytes.Equal(bytes.TrimSpace(perPageRaw), []byte("null")) {
		var perPage int64
		if err := json.Unmarshal(perPageRaw, &perPage); err != nil {
			return nil, errors.New("perPage is invalid")
		}
		env.PerPage = &perPage
	}
	return env, nil
}

func parseProviderOwnedKey(raw json.RawMessage) (*OwnedKey, error) {
	if len(bytes.TrimSpace(raw)) == 0 || bytes.TrimSpace(raw)[0] != '{' {
		return nil, errors.New("owned key is not an object")
	}
	var p providerOwnedKey
	if err := json.Unmarshal(raw, &p); err != nil {
		return nil, err
	}
	if p.ID == nil || *p.ID <= 0 || p.GameID == nil || *p.GameID <= 0 || p.Game == nil {
		return nil, errors.New("owned key required identity is missing")
	}
	if p.Game.ID == nil || *p.Game.ID <= 0 || *p.Game.ID != *p.GameID {
		return nil, errors.New("owned key game identity is invalid")
	}
	if p.Game.Title == nil || !validTitle(*p.Game.Title) {
		return nil, errors.New("owned key game title is invalid")
	}
	price := int64(0)
	if p.Game.MinPrice != nil {
		if *p.Game.MinPrice < 0 {
			return nil, errors.New("owned key minPrice is invalid")
		}
		price = *p.Game.MinPrice
	}
	published := false
	if p.Game.Published != nil {
		published = *p.Game.Published
	}

	return &OwnedKey{
		ID:     *p.ID,
		GameID: *p.GameID,
		Game: &OwnedGame{
			ID:        *p.Game.ID,
			Title:     *p.Game.Title,
			MinPrice:  price,
			Published: published,
		},
	}, nil
}

func validTitle(s string) bool {
	if s == "" || !utf8.ValidString(s) {
		return false
	}
	return utf8.RuneCountInString(s) <= maximumTitleRunes
}
