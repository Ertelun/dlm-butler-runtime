package buildinfo

import (
	"fmt"
	"strconv"
	"time"
)

var (
	Version  = "c0r2-ownedkeys-diag-dev"
	BuiltAt  = ""
	Commit   = ""
	Baseline = ""
)

func VersionString() string {
	timeString := "no build date"
	if BuiltAt != "" {
		if epoch, err := strconv.ParseInt(BuiltAt, 10, 64); err == nil {
			timeString = fmt.Sprintf("built on %s", time.Unix(epoch, 0).UTC().Format("Jan _2 2006 @ 15:04:05 UTC"))
		}
	}
	res := fmt.Sprintf("%s, %s", Version, timeString)
	if Commit != "" {
		res += ", ref " + Commit
	}
	if Baseline != "" {
		res += ", baseline " + Baseline
	}
	return res
}
