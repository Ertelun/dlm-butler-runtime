module dld.local/c0r2runtime

go 1.23.0
